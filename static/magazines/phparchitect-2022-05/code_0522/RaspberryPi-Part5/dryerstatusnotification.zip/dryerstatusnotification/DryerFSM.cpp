#include <iostream>
#include <stdlib.h>
#include "tinyfsm.hpp"
#include "DryerFSM.hpp"
#include "fsmlist.hpp"

#define DRYER_STATUS_SEND_TEXT_MSG_ENABLED true

using namespace std;

// ----------------------------------------------------------------------------
// Forward Declarations
//
class DryerOff;
class DryerGoingOn;
class DryerOn;
class DryerGoingOff;

// ----------------------------------------------------------------------------
// Static Constant Definitions
//
const float DryerFSM::GFORCE_OSCILLATION_TOLLERANCE = 0.02;
const int DryerFSM::GFORCE_OSCILLATION_TIMEOUT = 10; // In Seconds

// ----------------------------------------------------------------------------
// Static Definitions
//

// ----------------------------------------------------------------------------
// Transition Functions
//

// ----------------------------------------------------------------------------
// State: DryerOff
//
class DryerOff : public DryerFSM
{
    void entry() override
    {
        cout << "Dryer: Off" << endl;
    }

    void react(GForceOscillationEvent const & e) override
    {
        if (e.gForceOscillation > GFORCE_OSCILLATION_TOLLERANCE)
        {
        	transit<DryerGoingOn>();
        }
    }
};

// ----------------------------------------------------------------------------
// State: DryerGoingOn
//
class DryerGoingOn : public DryerFSM
{
	void entry() override // Start timer
    {
        cout << "Dryer: Going On" << endl;

        startGForceOscillationTolleranceTime = chrono::steady_clock::now();
    }

	void react(GForceOscillationEvent 		const & e) override
    {
        chrono::steady_clock::time_point nowTime = chrono::steady_clock::now();

        chrono::steady_clock::duration timeDiff = nowTime - startGForceOscillationTolleranceTime;

        int duration = chrono::duration_cast<chrono::seconds>(timeDiff).count();

        if (e.gForceOscillation < GFORCE_OSCILLATION_TOLLERANCE)
        {
        	transit<DryerOff>();
        }
        else if (duration > GFORCE_OSCILLATION_TIMEOUT)
        {
             transit<DryerOn>();
        }
    }
};

// ----------------------------------------------------------------------------
// State: DryerOn
//
class DryerOn : public DryerFSM
{
    void entry() override
    {
        cout << "Dryer: On" << endl;
    }

    void react(GForceOscillationEvent const & e) override
    {
        if (e.gForceOscillation < GFORCE_OSCILLATION_TOLLERANCE)
        {
            transit<DryerGoingOff>();
        }
    }
};

// ----------------------------------------------------------------------------
// State: DryerGoingOff
//
class DryerGoingOff : public DryerFSM
{
    void entry() override
    {
        cout << "Dryer: Going Off" << endl;

        startGForceOscillationTolleranceTime = chrono::steady_clock::now();
    }

    void react(GForceOscillationEvent const & e) override
    {
        chrono::steady_clock::time_point nowTime = chrono::steady_clock::now();

        chrono::steady_clock::duration timeDiff = nowTime - startGForceOscillationTolleranceTime;

        int duration = chrono::duration_cast<chrono::seconds>(timeDiff).count();

        if (e.gForceOscillation > GFORCE_OSCILLATION_TOLLERANCE)
        {
            transit<DryerOn>();
        }
        else if (duration > GFORCE_OSCILLATION_TIMEOUT)
        {
            #ifdef DRYER_STATUS_SEND_TEXT_MSG_ENABLED
            cout << "\tSend notification: Dryer is Off" << endl;
            system("echo \"Dryer is Off.\" | mail -s \"Dryer Status\" 6081234567@mms.att.net");
            #endif // DRYER_STATUS_SEND_TEXT_MSG_ENABLED

            transit<DryerOff>();
        }
    }
};

// ----------------------------------------------------------------------------
// Base state: Default implementations
//

void DryerFSM::react(GForceOscillationEvent const &)
{
    cout << "Call event ignored" << endl;
}

chrono::steady_clock::time_point DryerFSM::startGForceOscillationTolleranceTime
        = std::chrono::steady_clock::now();

// ----------------------------------------------------------------------------
// Initial State Definition
//
FSM_INITIAL_STATE(DryerFSM, DryerOff);
