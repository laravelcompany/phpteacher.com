To compile the Dryer Finite State Machine into the executable: dryer_status_notify on the Raspberry Pi:

g++ -std=c++11 -o dryer_status_notify dryer_status_notify.cpp GForceOscillation.cpp DryerFSM.cpp -lmysqlclient -lmysqlcppconn