#ifndef GFORCE_OSCILLATION__CPP
#define GFORCE_OSCILLATION__CPP
#include "GForceOscillation.hpp"

// ----------------------------------------------------------------------------
// Static Constant Definitions
//
const int GForceOscillation::MV_AVG_VEC_SIZE = 11;

// Constructor
GForceOscillation::GForceOscillation()
{
    m_mv_avg_axis_vec.clear();
    m_min_max_axis_vec.clear();
}

// Destructor
GForceOscillation::~GForceOscillation()
{
}

void GForceOscillation::appendMovingAverageData(tAxis axis)
{
    m_mv_avg_axis_vec.push_back(axis);

    if (m_mv_avg_axis_vec.size() > MV_AVG_VEC_SIZE)
    {
        m_mv_avg_axis_vec.erase(m_mv_avg_axis_vec.begin());
    }
}

bool GForceOscillation::isMovingAverageDataAvailable()
{
    bool retVal = false;

    if (m_mv_avg_axis_vec.size() == MV_AVG_VEC_SIZE)
    {
        retVal = true;
    }

    return retVal;
}

tAxis GForceOscillation::getMovingAverage()
{
    tAxis total;

    tAxis retVal;

    vector<tAxis>::const_iterator iter;

    for (iter = m_mv_avg_axis_vec.begin(); iter != m_mv_avg_axis_vec.end(); iter++)
    {
        total.X += iter->X;
        total.Y += iter->Y;
        total.Z += iter->Z;
    }

    if (total.X != 0.0 && total.Y != 0.0 && total.Z != 0.0)
    {
        retVal.X = total.X / m_mv_avg_axis_vec.size();
        retVal.Y = total.Y / m_mv_avg_axis_vec.size();
        retVal.Z = total.Z / m_mv_avg_axis_vec.size();
    }

    return retVal;
}

void GForceOscillation::appendMinMaxData(tAxis axis)
{
    m_min_max_axis_vec.push_back(axis);

    if (m_min_max_axis_vec.size() > MV_AVG_VEC_SIZE)
    {
        m_min_max_axis_vec.erase(m_min_max_axis_vec.begin());
    }
}

bool GForceOscillation::isMinMaxDataAvailable()
{
    bool retVal = false;

    if (m_min_max_axis_vec.size() == MV_AVG_VEC_SIZE)
    {
        retVal = true;
    }

    return retVal;
}

tAxis GForceOscillation::getMinMaxDiff()
{
    tAxis retVal;
    tAxis min;
    tAxis max;

    vector<tAxis>::const_iterator iter;

    for (iter = m_min_max_axis_vec.begin(); iter != m_min_max_axis_vec.end(); iter++)
    {
        if (iter == m_min_max_axis_vec.begin())
        {
            min.X = max.X = iter->X;
            min.Y = max.Y = iter->Y;
            min.Z = max.Z = iter->Z;
        } // END IF 1st iteration
        else
        {
            if (iter->X < min.X)
            {
                min.X = iter->X;
            }
            else if (iter->X > max.X)
            {
                max.X = iter->X;
            }

            if (iter->Y < min.Y)
            {
                min.Y = iter->Y;
            }
            else if (iter->Y > max.Y)
            {
                max.Y = iter->Y;
            }

            if (iter->Z < min.Z)
            {
                min.Z = iter->Z;
            }
            else if (iter->Z > max.Z)
            {
                max.Z = iter->Z;
            }
        } // END ELSE all other iterations except the 1st
    } // END FOR EACH min_max_axis_vec item

    retVal.X = max.X - min.X;
    retVal.Y = max.Y - min.Y;
    retVal.Z = max.Z - min.Z;

    return retVal;
}

#endif // GFORCE_OSCILLATION__CPP
