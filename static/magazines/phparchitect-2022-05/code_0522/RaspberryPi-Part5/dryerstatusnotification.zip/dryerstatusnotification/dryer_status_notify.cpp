#include <stdlib.h>
#include <iostream>
#include <memory>
#include <unistd.h>
#include <stdexcept>
#include <string>

#include "/usr/include/mysql/mysql.h"

#include "GForceOscillation.hpp"
#include "fsmlist.hpp"

// Constants
#define HOST "localhost"
#define USER "accelerometer"
#define PASSWD "accelerometer"
#define DB "AccelerometerData"

MYSQL *connection, mysql;
MYSQL_RES *result;
MYSQL_ROW row;
int query_state;

using namespace std;

int main()
{
    cout << "Dryer FSM Status" << endl;
    cout << endl;

    GForceOscillation g_force_oscillation;

    fsm_list::start();

    GForceOscillationEvent g_force_oscillation_event;

    //initialize database connection
    mysql_init(&mysql);

    // the three zeros are: Which port to connect to, which socket to connect to
    // and what client flags to use.  unless you're changing the defaults you only need to put 0 here
    connection = mysql_real_connect(&mysql,HOST,USER,PASSWD,DB,0,0,0);

    // Report error if failed to connect to database
    if (connection == NULL)
    {
        cout << mysql_error(&mysql) << endl;
        return 1;
    }

    // Forever Loop
    while(1)
    {
        string newest_entry_query = "SELECT axis_x, axis_y, axis_z FROM accelerometer_data ORDER BY created DESC LIMIT 1";

        // Send newest entry query to database
        query_state = mysql_query(connection, newest_entry_query.c_str());

        if(query_state != 0)
        {
            cout << mysql_error(connection) << endl;
            return 1;
        }

        // Get result of query (newest axis data)
        result = mysql_store_result(connection);

        row = mysql_fetch_row(result);

        tAxis axis;

        axis.X = stof(row[0]);
        axis.Y = stof(row[1]);
        axis.Z = stof(row[2]);

        // Free result or a memory leak will occur
        mysql_free_result(result);

        g_force_oscillation.appendMovingAverageData(axis);

        if (g_force_oscillation.isMovingAverageDataAvailable())
        {
            g_force_oscillation.appendMinMaxData(g_force_oscillation.getMovingAverage());

            if (g_force_oscillation.isMinMaxDataAvailable())
            {
                tAxis min_max_diff = g_force_oscillation.getMinMaxDiff();

                // We are only concerned with the Z axis difference for driving
                // our state machine
                g_force_oscillation_event.gForceOscillation = min_max_diff.Z;

                send_event(g_force_oscillation_event);

                /*
                cout << "Min/Max Diff: X: " << min_max_diff.X
                        << ", Y: " << min_max_diff.Y
                        << ", Z: " << min_max_diff.Z
                        << endl;
                */
            }
        }

        usleep(100000); // 100 milliseconds
    } // End forever loop

    cout << "Done." << endl;
    return EXIT_SUCCESS;
}
